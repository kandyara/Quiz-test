PHP

<?php
session_start(); // Start the session to store quiz progress

// Initialize variables
$currentQuestionIndex = $_SESSION['currentQuestionIndex'] ?? 0; // Restore progress from session
$correctAnswers = $_SESSION['correctAnswers'] ?? 0; // Restore progress from session
$totalQuestions = count($questions); // Get total number of questions from array

// Check if quiz is complete
if ($currentQuestionIndex == $totalQuestions) {
  // Display final score
  echo "<div class='quiz-result'>Your score is $correctAnswers out of $totalQuestions</div>";
  echo "<button type='button' id='play-again'>Play Again!</button>";
  exit;
}

// Update quiz content with the next question
$questionData = $questions[$currentQuestionIndex];
$questionText = $questionData['question'];
$answerOptions = $questionData['answers'];

// Store progress in session
$_SESSION['currentQuestionIndex'] = $currentQuestionIndex;
$_SESSION['correctAnswers'] = $correctAnswers;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Php Test Quiz</title>

  <link rel="stylesheet" href="main.css">
</head>
<body class="flex">
  <div class="wrapper">
    <div class="quiz-container">
      <div class="quiz-head">
        <h1>Quiz Test</h1>
        <div class="quiz-score flex">
          <span id="correct-score"><?php echo $correctAnswers; ?></span>/<span id="total-question"><?php echo $totalQuestions; ?></span>
        </div>
      </div>
      <div class="quiz-body">
        <h2><?php echo $questionText; ?></h2>
        <ul class="quiz-options">
          <?php
          $optionIndex = 1;
          foreach ($answerOptions as $option) {
            echo "<li>$optionIndex. $option</li>";
            $optionIndex++;
          }
          ?>
        </ul>
        <div id="result">
          </div>
      </div>
      <div class="quiz-foot">
        <button
 
type="button" id="check-answer">Check
 
Answer</button>
        <button
 
type="button" id="play-again">Play
 
Again!</button>
      </div>
    </div>
  </div>

  <script
 
src="script.js"></script>
</body>
</html>
