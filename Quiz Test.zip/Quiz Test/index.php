<?php
// Process form submission and validate input
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['number_of_questions']) && isset($_POST['difficulty']) && isset($_POST['type'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $numberOfQuestions = $_POST['number_of_questions'];
    $difficulty = $_POST['difficulty'];
    $type = $_POST['type'];

    // Validate name, email, and additional fields
    if (empty($name)) {
        echo "Please enter your name.";
        exit;
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Please enter a valid email address.";
        exit;
    }

    if (empty($numberOfQuestions) || !is_numeric($numberOfQuestions) || $numberOfQuestions < 1 || $numberOfQuestions > 49) {
        echo "Please enter a valid number of questions (1-49).";
        exit;
    }

    if (empty($difficulty) || !in_array($difficulty, ['easy', 'medium', 'hard'])) {
        echo "Please select a valid difficulty (easy, medium, hard).";
        exit;
    }

    if (empty($type)) {
        echo "Please select a valid type of question.";
        exit;
    }

    // Process further steps after successful validation
    // ...

} else {
    // Display the form
    echo "<form action='index.php' method='post'>";
    echo "Name: <input type='text' id='name' name='name'><br>";
    echo "E-mail: <input type='text' name='email'><br>";
    echo "Number of Questions: <input type='number' min='1' max='49' name='number_of_questions'><br>";
    echo "Difficulty: <select name='difficulty'>";
    echo
 
"<option value='easy'>Easy</option>";
    echo
 
"<option value='medium'>Medium</option>";
    echo
 
"<option value='hard'>Hard</option>";
    echo
 
"</select><br>";
    echo "Type of Question: <input type='text' name='type'><br>";
    echo "<input type='submit'>";
    echo "</form>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php Test Quiz</title>

    <link rel="stylesheet" href="main.css">
</head>
<body class="flex">

    <form action="index.php" method="post">
        Name: <input type="text" id="name" name="name"><br>
        E-mail: <input type="text" name="email"><br>
        Number of Questions: <input type="number" min="1" max="49" name="number_of_questions"><br>
        Difficulty: <select
 
name="difficulty">
            <option
 
value="easy">Easy</option>
            <option
 
value="medium">Medium</option>
            <option
 
value="hard">Hard</option>
        </select><br>
        Type of Question: <input type="text" name="type"><br>
        <input type="submit">
    </form>

    <script src="script.js"></script>
</body>
</html>